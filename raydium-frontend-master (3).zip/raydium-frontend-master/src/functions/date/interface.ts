export type TimeStamp = string | number | Date
export type TimeStampLiteral = Exclude<TimeStamp, Date>
